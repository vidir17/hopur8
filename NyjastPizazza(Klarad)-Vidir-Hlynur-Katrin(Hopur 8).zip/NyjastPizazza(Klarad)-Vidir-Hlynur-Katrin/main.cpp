#include "mainui.h" //Klasi fyrir Main user interface
#include <iostream>
using namespace std;
int main()
{
    MainUI mainUI; //kallar � klasa me� valmoguleika notanda
    mainUI.mainMenu(); //prentar valmoguleika a skjainn
    return 0;
}
