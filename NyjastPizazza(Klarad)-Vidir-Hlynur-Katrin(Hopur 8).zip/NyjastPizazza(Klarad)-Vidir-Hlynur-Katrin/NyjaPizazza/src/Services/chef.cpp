#include "chef.h"

Chef::Chef()
{
    //ctor
}

