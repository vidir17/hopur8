#ifndef MAINUI_H
#define MAINUI_H
//#include "pizza.h"
//#include "topping.h"
#include "managementui.h"


//#include <stdio.h>
//#include <iostream>
//#include <string>

using namespace std;

class MainUI
{
    public:
        void mainMenu();

    private:
};

#endif // MAINUI_H
