#ifndef SERVICE_H
#define SERVICE_H



class Service
{
    public:
        //void calculatePrice(); //fall sem s�kir baked, (reiknar ut verd) og merkir finished!

    private:
        //repostuff
};

#endif // SERVICE_H
