#ifndef ORDERS_H
#define ORDERS_H

#include "pizza.h"
#include "topping.h"
#include "toppingrepo.h"

#include <vector>
#include <iostream>

class Orders
{
    public:
        Orders();

        //void makeOrder(); //fall sem tekur ni�ur pontun og skilar af s�r skranni orders.txt


    private:
        //repository
};

#endif // ORDERS_H
