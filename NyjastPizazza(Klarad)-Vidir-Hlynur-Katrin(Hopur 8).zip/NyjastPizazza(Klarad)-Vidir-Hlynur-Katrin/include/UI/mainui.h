#ifndef MAINUI_H
#define MAINUI_H
#include "managementui.h"
#include "orders.h"
#include "chefui.h"
#include "orderui.h"
#include "serviceui.h"
#include "finishorder.h"
using namespace std;

class MainUI
{
    public:
        void mainMenu();
};

#endif // MAINUI_H
