#ifndef VALMYNDUI_H
#define VALMYNDUI_H

//#include "pizzarepo.h"
//#include "toppingrepo.h"

class ValmyndUI
{
    public:
        ValmyndUI();
        virtual ~ValmyndUI();

        void startUI(); //choices for management

    private:
        //PizzaRepo pizzarepo;
        //ToppingRepo toppingrepo;
};

#endif // VALMYNDUI_H
