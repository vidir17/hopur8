#ifndef SERVICE_H
#define SERVICE_H
#include "toppingrepo.h"
using namespace std;

class Service
{
    public:
        void calculatePrice();
        void deliverOrder();
        void completed();
        void delivered();
};

#endif // SERVICE_H
