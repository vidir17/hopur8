#ifndef REPOSITORY_H
#define REPOSITORY_H
#include "topping.h"
#include "pizza.h"

class Repository
{
    public:

        void addPizza();
        void addTopping();
        void retrieveTopping();

    private:
};

#endif // REPOSITORY_H
