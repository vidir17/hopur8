#ifndef INVALIDYEAR_H
#define INVALIDYEAR_H


class InvalidYear
{

};

#endif // INVALIDYEAR_H
