#ifndef INVALIDNAME_H
#define INVALIDNAME_H


class InvalidName
{};

#endif // INVALIDNAME_H
