#ifndef INVALIDWAGES_H
#define INVALIDWAGES_H


class InvalidWages
{
};

#endif // INVALIDWAGES_H
