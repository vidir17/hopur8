#ifndef INVALIDMONTH_H
#define INVALIDMONTH_H


class InvalidMonth
{
};

#endif // INVALIDMONTH_H
