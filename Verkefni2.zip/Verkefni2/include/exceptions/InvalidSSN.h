#ifndef INVALIDSSN_H
#define INVALIDSSN_H


class InvalidSSN
{
};

#endif // INVALIDSSN_H
