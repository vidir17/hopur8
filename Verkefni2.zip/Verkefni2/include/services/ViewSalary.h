#ifndef VIEWSALARY_H
#define VIEWSALARY_H


class ViewSalary
{
    public:
        ViewSalary();
        virtual ~ViewSalary();

    protected:

    private:
};

#endif // VIEWSALARY_H
