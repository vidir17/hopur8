#include "staffui.h"
#include "employee.h"

#include <iostream>

/* H�pur 8
    Hlynur V��isson
    Katr�n Gu�mundsd�ttir
    V��ir Sn�r Svanbj�rnsson
 */

using namespace std;

int main()
{
    StaffUI staffui; //kallar � klasa fyrir valm�guleika notanda
    staffui.mainMenu(); //prentar � skj�inn

    return 0;
}
