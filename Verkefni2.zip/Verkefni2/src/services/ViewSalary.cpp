#include "ViewSalary.h"

ViewSalary::ViewSalary()
{
    //ctor
}

ViewSalary::~ViewSalary()
{
    //dtor
}
