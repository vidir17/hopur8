#include "readinfo.h"

ReadInfo::ReadInfo()
{
    //ctor
}

void AddSalary::addInfo(const Employee& employee){
    //validate
    salary.readInfo(employee);
}


