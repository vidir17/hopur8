#ifndef CHEF_H
#define CHEF_H


class Chef
{
    public:
        Chef();
        // void viewOrder(); //fall sem s�kir orders.txt pizzur merktar i vinnslu
        // void makingPizza(); //fall sem skilar baked, pizzur merktar tilbunar

    private:
        //reposhit
};

#endif // CHEF_H
