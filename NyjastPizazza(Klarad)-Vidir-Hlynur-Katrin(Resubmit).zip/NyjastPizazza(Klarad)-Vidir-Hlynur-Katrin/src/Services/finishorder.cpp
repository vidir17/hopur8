#include "finishorder.h"

void FinishOrder::call()
{
    toppingrepo.call();
}
void FinishOrder::addPhoneNumber()
{
    toppingrepo.addPhoneNumber();
}
void FinishOrder::addTime()
{
    toppingrepo.addtime();
}
