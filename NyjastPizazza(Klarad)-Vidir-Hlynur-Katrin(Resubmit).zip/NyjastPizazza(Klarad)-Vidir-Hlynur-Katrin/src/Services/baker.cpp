#include "baker.h"

void Baker::bakingList()
{
    ToppingRepo toppingrepo;
    toppingrepo.bakinglist();
}
