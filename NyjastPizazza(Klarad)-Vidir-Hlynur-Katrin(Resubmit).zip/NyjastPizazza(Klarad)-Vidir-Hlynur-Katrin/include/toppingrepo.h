#ifndef TOPPINGREPO_H
#define TOPPINGREPO_H


class ToppingRepo
{
    public:
        ToppingRepo();
        virtual ~ToppingRepo();

    protected:

    private:
};

#endif // TOPPINGREPO_H
