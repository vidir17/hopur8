#ifndef BAKER_H
#define BAKER_H
#include "toppingrepo.h"
using namespace std;
class Baker
{
    public:
        void bakingList();

};

#endif // BAKER_H
