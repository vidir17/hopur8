#ifndef ORDERUI_H
#define ORDERUI_H
#include "orders.h"

class OrderUI
{
    public:
        void makeOrder();
        void createOrder();
        void viewPending();
        void createAdditional();

};

#endif // ORDERUI_H
