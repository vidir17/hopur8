#ifndef SERVICEUI_H
#define SERVICEUI_H
#include "service.h"
using namespace std;
class ServiceUI
{
    public:
        void calculatePrice();
};

#endif // SERVICEUI_H
